import argparse, os
import datetime, time, random
from torch.utils.tensorboard import SummaryWriter

import numpy as np
import pandas as pd

from scipy.ndimage import gaussian_filter1d

import torch
import torch.nn as nn
from torch_geometric.nn import GCNConv

seed = 0
np.random.seed(seed)
torch.manual_seed(seed)
random.seed(seed)

class TimeEncoder(nn.Module):
    '''
    Filter the velocity and acceleration inputs, add kinetic-based time contribution (v*t, a*(t^2)),
    and calculates the change in theta of a single joint-axis
        inputs: v (velocity), a (acceleration), t (time)
        outputs: delta_theta, filtered_v, filtered_a
    '''
    def __init__(self, args):
        super(TimeEncoder, self).__init__()

        self.kfe = False
        if args.filter_num_layers!=0:
            self.lstm0 = nn.LSTM(input_size=1, hidden_size=args.filter_hidden_size, num_layers=args.filter_num_layers, batch_first=True)
            self.lstm1 = nn.LSTM(input_size=1, hidden_size=args.filter_hidden_size, num_layers=args.filter_num_layers, batch_first=True)
            self.dense0 = nn.Linear(args.filter_hidden_size, 1)
            self.dense1 = nn.Linear(args.filter_hidden_size, 1)
            self.kfe = True
        
        self.activation = nn.Tanh()

        self.lstm2 = nn.LSTM(input_size=1, hidden_size=args.lstm_hidden_size, num_layers=args.lstm_num_layers, batch_first=True)
        self.lstm3 = nn.LSTM(input_size=1, hidden_size=args.lstm_hidden_size, num_layers=args.lstm_num_layers, batch_first=True)
        self.dense2 = nn.Linear(2*args.lstm_hidden_size, 64)
        self.dropout = nn.Dropout(args.dropout_rate)
        self.dense3 = nn.Linear(64, 128)
        self.dense4 = nn.Linear(128, 32)
        self.dense5 = nn.Linear(32, 1)
    
    def forward(self, v, a, t):

        if self.kfe:
            v0, _ = self.lstm0(v)
            v0 = self.dense0(self.activation(v0))
            a0, _ = self.lstm1(a)
            a0 = self.dense1(self.activation(a0))
        else:
            v0, a0 = v.clone(), a.clone()

        v, _ = self.lstm2(v0)
        a, _ = self.lstm3(a0)
        delta_theta = torch.cat([self.activation(v[:, -1, :])*t, self.activation(a[:, -1, :])*(t**2)], dim=1)
        delta_theta = self.dense2(delta_theta)
        delta_theta = self.dropout(delta_theta)
        delta_theta = self.dense3(delta_theta)
        delta_theta = self.dropout(delta_theta)
        delta_theta = self.dense4(delta_theta)
        delta_theta = self.dropout(delta_theta)
        delta_theta = self.dense5(delta_theta)
        return delta_theta, v0[:,-1], a0[:,-1]

class HandEncoder(nn.Module):
    '''
    Combines the single joint-axis models to get the encodings for the whole hand
    '''
    def __init__(self, args, num_joints=14):
        super(HandEncoder, self).__init__()
        self.num_joints = num_joints
        self.joint_models = nn.ModuleList([TimeEncoder(args) for _ in range(num_joints*3)])
    
    def forward(self, vs, acs, t):
        delta_theta = []
        v = []
        a = []
        for i in range(self.num_joints*3):
            _dt, _v, _a = self.joint_models[i](vs[:, i, :], acs[:, i, :], t)
            delta_theta.append(_dt)
            v.append(_v)
            a.append(_a)
        delta_theta = torch.stack(delta_theta, dim=1)
        v = torch.stack(v, dim=1)
        a = torch.stack(a, dim=1)
        return delta_theta, v, a

class GNNDecoder_V0(nn.Module):
    '''
    Calculates the theta_prediction (xp) from initial_theta (x0) and delta_theta  (dp)
    and adjusts the rotations of the joints based on their neighbouring joints
    '''
    def __init__(self, edge_index, args, input_dim=3, output_dim=3):
        super(GNNDecoder_V0, self).__init__()
        self.weight = nn.Linear(1,1, bias=False)
    
    def forward(self, x0, dp):
        x = self.weight(dp) + x0
        return x

class GNNDecoder_V1(nn.Module):
    '''
    Calculates the theta_prediction (xp) from initial_theta (x0) and delta_theta  (dp)
    and adjusts the rotations of the joints based on their neighbouring joints
    '''
    def __init__(self, edge_index, args, input_dim=3, output_dim=3):
        super(GNNDecoder_V1, self).__init__()
        self.weight = nn.Linear(1,1, bias=False)
        self.conv1 = GCNConv(input_dim, output_dim)
        self.edge_index = edge_index
        self.activation = nn.Identity()
    
    def forward(self, x0, dp):
        xp = self.weight(dp) + x0
        xp = torch.reshape(xp, (-1, 14, 3))
        x1 = self.conv1(xp, self.edge_index)
        x = self.activation(x1) + xp
        x = x.reshape(x.shape[0], -1, 1)
        return x

class GNNDecoder_V3(nn.Module):
    '''
    Calculates the theta_prediction (xp) from initial_theta (x0) and delta_theta  (dp)
    and adjusts the rotations of the joints based on their neighbouring joints
    '''
    def __init__(self, edge_index, args, input_dim=3, output_dim=3):
        super(GNNDecoder_V3, self).__init__()
        self.weight = nn.Linear(1,1, bias=False)
        self.conv1 = GCNConv(input_dim, args.gnn_hidden_dim)
        self.conv2 = GCNConv(args.gnn_hidden_dim, args.gnn_hidden_dim)
        self.conv3 = GCNConv(args.gnn_hidden_dim, output_dim)
        self.edge_index = edge_index
        self.activation = nn.Identity()
    
    def forward(self, x0, dp):
        xp = self.weight(dp) + x0
        xp = torch.reshape(xp, (-1, 14, 3))
        x1 = self.conv1(xp, self.edge_index)
        x = self.activation(x1)
        x = self.conv2(x, self.edge_index) + x1
        x = self.activation(x)
        x = self.conv3(x, self.edge_index) + xp
        x = x.reshape(x.shape[0], -1, 1)
        return x

class GNNDecoder_V5(nn.Module):
    '''
    Calculates the theta_prediction (xp) from initial_theta (x0) and delta_theta  (dp)
    and adjusts the rotations of the joints based on their neighbouring joints
    '''
    def __init__(self, edge_index, args, input_dim=3, output_dim=3):
        super(GNNDecoder_V5, self).__init__()
        self.weight = nn.Linear(1,1, bias=False)
        self.conv1 = GCNConv(input_dim, args.gnn_hidden_dim)
        self.conv2 = GCNConv(args.gnn_hidden_dim, 2*args.gnn_hidden_dim)
        self.conv3 = GCNConv(2*args.gnn_hidden_dim, 2*args.gnn_hidden_dim)
        self.conv4 = GCNConv(2*args.gnn_hidden_dim, args.gnn_hidden_dim)
        self.conv5 = GCNConv(args.gnn_hidden_dim, output_dim)
        self.edge_index = edge_index
        self.activation = nn.Identity()
    
    def forward(self, x0, dp):
        xp = self.weight(dp) + x0
        xp = torch.reshape(xp, (-1, 14, 3))
        x1 = self.conv1(xp, self.edge_index)
        x = self.activation(x1)
        x2 = self.conv2(x, self.edge_index)
        x = self.activation(x2)
        x = self.conv3(x, self.edge_index) + x2
        x = self.activation(x)
        x = self.conv4(x, self.edge_index) + x1
        x = self.activation(x)
        x = self.conv5(x, self.edge_index) + xp
        x = x.reshape(x.shape[0], -1, 1)
        return x

class GNNDecoder_V7(nn.Module):
    '''
    Calculates the theta_prediction (xp) from initial_theta (x0) and delta_theta  (dp)
    and adjusts the rotations of the joints based on their neighbouring joints
    '''
    def __init__(self, edge_index, args, input_dim=3, output_dim=3):
        super(GNNDecoder_V7, self).__init__()
        self.weight = nn.Linear(1,1, bias=False)
        self.conv1 = GCNConv(input_dim, args.gnn_hidden_dim)
        self.conv2 = GCNConv(args.gnn_hidden_dim, 2*args.gnn_hidden_dim)
        self.conv3 = GCNConv(2*args.gnn_hidden_dim, 4*args.gnn_hidden_dim)
        self.conv4 = GCNConv(4*args.gnn_hidden_dim, 4*args.gnn_hidden_dim)
        self.conv5 = GCNConv(4*args.gnn_hidden_dim, 2*args.gnn_hidden_dim)
        self.conv6 = GCNConv(2*args.gnn_hidden_dim, args.gnn_hidden_dim)
        self.conv7 = GCNConv(args.gnn_hidden_dim, output_dim)
        self.edge_index = edge_index
        self.activation = nn.Identity()
    
    def forward(self, x0, dp):
        xp = self.weight(dp) + x0
        xp = torch.reshape(xp, (-1, 14, 3))
        x1 = self.conv1(xp, self.edge_index)
        x = self.activation(x1)
        x2 = self.conv2(x, self.edge_index)
        x = self.activation(x2)
        x3 = self.conv3(x, self.edge_index)
        x = self.activation(x3)
        # Following layers have skip connections (x3, x2, x1, xp)
        x = self.conv4(x, self.edge_index) + x3
        x = self.activation(x)
        x = self.conv5(x, self.edge_index) + x2
        x = self.activation(x)
        x = self.conv6(x, self.edge_index) + x1
        x = self.activation(x)
        x = self.conv7(x, self.edge_index) + xp
        x = x.reshape(x.shape[0], -1, 1)
        return x

# Different versions of GNNDecoder with different number of GCN layers
GNNDecoder = {
    0: GNNDecoder_V0,
    1: GNNDecoder_V1,
    3: GNNDecoder_V3,
    5: GNNDecoder_V5,
    7: GNNDecoder_V7
}

class Model(nn.Module):
    '''
    Combination of hand encoder and gnn based decoder
    '''
    def __init__(self, args, num_joints=14, device='cpu'):
        super(Model, self).__init__()
        self.hand_encoder = HandEncoder(args, num_joints)
        self.gnn_decoder = GNNDecoder[args.gnn_num_layers](torch.tensor([[0,2,3,5,6,8,9,11,12], [1,3,4,6,7,9,10,12,13]], dtype=torch.long).to(device), args)

    def forward(self, x, t):
        x0, vs, acs = x[:,:,0], x[:,:,1:6], x[:,:,6:]
        delta_theta, v, a = self.hand_encoder(vs, acs, t)
        x = self.gnn_decoder(x0, delta_theta)
        return x , v, a

def moving_average_filter(x, n):
    out = x[:-n]
    for i in range(1,n):
        out += x[i:i-n]
    out /= n
    return out

class Dataset(torch.utils.data.Dataset):
    def __init__(self, args, split='train', device='cpu', times=[]):
        self.data_path = args.data_path

        self.times = times
        self.split = split
        if split=='train': self.users = [1,2,3,4,5]
        elif split=='valid': self.users = [6]
        elif split=='test': self.users = [7]
        else: self.users = []

        self.data = []
        self.joints = [ 'B12x', 'B12y', 'B12z', #0
                        'B11x', 'B11y', 'B11z', #3
                        'B23x', 'B23y', 'B23z', #6
                        'B22x', 'B22y', 'B22z', #9
                        'B21x', 'B21y', 'B21z', #12
                        'B33x', 'B33y', 'B33z', #15
                        'B32x', 'B32y', 'B32z', #18
                        'B31x', 'B31y', 'B31z', #21
                        'B43x', 'B43y', 'B43z', #24
                        'B42x', 'B42y', 'B42z', #27
                        'B41x', 'B41y', 'B41z', #30
                        'B53x', 'B53y', 'B53z', #33
                        'B52x', 'B52y', 'B52z', #36
                        'B51x', 'B51y', 'B51z'] #39
        
        # filters
        self.maf = lambda x: moving_average_filter(x, n=10)
        self.gaussian = lambda x: gaussian_filter1d(x, sigma=3, axis=0)

        self.load_data()
        self.data = torch.Tensor(self.data).float().to(device)
    
    def load_data(self):
        for user in self.users:
            for hand in ['left', 'right']:
                theta = pd.read_csv(f'{self.data_path}/p{user}_theta_{hand}.csv')[self.joints].to_numpy()

                indices = np.arange(0, theta.shape[0], 1)
                theta = theta[indices]

                # The first part of kinematic feature extractor is implemented here to avoid re-calculating the same values
                theta_maf = self.maf(theta.copy())          # Moving average filter
                theta_gauss = self.gaussian(theta.copy())   # Gaussian filter

                # Calculate velocities, accelerations, and target theta
                v_maf = theta_maf[1:] - theta_maf[:-1]
                a_maf = v_maf[1:] - v_maf[:-1]
                v_gauss = theta_gauss[1:] - theta_gauss[:-1]
                a_gauss = v_gauss[1:] - v_gauss[:-1]
                targs = []
                for t in self.times:
                    targs.append(np.expand_dims(theta[int(t/10):int(t/10)-120], -1))
                theta_target = np.concatenate(targs, axis=-1)

                # Balance the lengths of the vectors and add extra dimension for concatenation
                theta = np.expand_dims(theta[20:-150], -1)
                v_maf = np.expand_dims(v_maf, -1)
                v_maf_4 = v_maf[5:-154]
                v_maf_3 = v_maf[6:-153]
                v_maf_2 = v_maf[7:-152]
                v_maf_1 = v_maf[8:-151]
                v_maf_0 = v_maf[9:-150]
                a_maf = np.expand_dims(a_maf, -1)
                a_maf_4 = a_maf[4:-154]
                a_maf_3 = a_maf[5:-153]
                a_maf_2 = a_maf[6:-152]
                a_maf_1 = a_maf[7:-151]
                a_maf_0 = a_maf[8:-150]
                v_gauss = np.expand_dims(v_gauss[19:-150], -1)
                a_gauss = np.expand_dims(a_gauss[18:-150], -1)
                theta_target = theta_target[20:theta.shape[0]+20]

                # Concatenate the features and targets into the last dimension
                data = np.concatenate([theta, v_maf_4, v_maf_3, v_maf_2, v_maf_1, v_maf_0, a_maf_4, a_maf_3, a_maf_2, a_maf_1, a_maf_0, theta_target, v_gauss, a_gauss], axis=-1)
                self.data.append(data)

        self.data = np.expand_dims(np.concatenate(self.data, axis=0), axis=-1) # shape: [joint, features-targets, lstm_embed_dim=1] # Batch dim added to front by dataloader
    
    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, idx):
        return self.data[idx]

def train_time_independent(model, train_loader, val_loader, args, times, loss_weights):
    model.train()
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.ExponentialLR(optimizer, gamma=args.gamma)
    loss_fn = nn.MSELoss()
    best_val_loss, best_theta_loss = 1e10, 1e10

    # Initialize tensorboard
    train_log_dir = f'Logs/{datetime.datetime.now().strftime("%Y%m%d-%H%M%S")}-{args.exp}-all'
    writer = SummaryWriter(train_log_dir)
    for key,value in vars(args).items():
        writer.add_text(key, str(value), 0)

    len_t = len(times)

    print(f"Starting training at {datetime.datetime.now()}")
    start_time = time.time()
    for epoch in range(args.epochs):
        train_loss = 0
        for data in train_loader:
            inp = data[:,:,:11]         # theta_0, v_(-4)-v_(0), a_(-4)-a_(0)
            target = data[:,:,11:]      # theta_target[8], gaussian_velocity_target, gaussian_acceleration_target

            optimizer.zero_grad()
            output_x = torch.zeros_like(target[:,:,:len_t])
            for i,t in enumerate(times):
                output_x[:,:,i], output_v, output_a = model(inp, t)
            loss = loss_fn(torch.multiply(output_x, loss_weights), torch.multiply(target[:,:,:len_t], loss_weights)) + loss_fn(output_v, target[:,:,len_t]) + loss_fn(output_a, target[:,:,len_t+1])
            train_loss += loss.item()*data.shape[0]
            loss.backward()
            optimizer.step()

        train_loss /= len(train_loader.dataset)

        # print(f'Epoch: {epoch:03d}, Train Loss: {train_loss:.2f}')
        
        val_loss0, val_loss1, val_loss2 = np.zeros(len_t), np.zeros(len_t), np.zeros(len_t)
        with torch.no_grad():
            for i,t in enumerate(times):
                for data in val_loader:
                
                    inp = data[:,:,:11]         # theta_0, v_(-4)-v_(0), a_(-4)-a_(0)
                    target = data[:,:,11:]      # theta_target, gaussian_velocity_target, gaussian_acceleration_target

                    output = model(inp, t)
                    loss0 = loss_fn(output[0], target[:,:,i]) # MSE of theta
                    loss1 = loss_fn(output[1], target[:,:,len_t]) # MSE of velocity
                    loss2 = loss_fn(output[2], target[:,:,len_t+1]) # MSE of acceleration

                    val_loss0[i] += loss0.item()*data.shape[0]
                    val_loss1[i] += loss1.item()*data.shape[0]
                    val_loss2[i] += loss2.item()*data.shape[0]
                val_loss0[i] /= len(val_loader.dataset)
                val_loss1[i] /= len(val_loader.dataset)
                val_loss2[i] /= len(val_loader.dataset)
                val_loss = val_loss0[i]+val_loss1[i]+val_loss2[i]

                if (epoch+1)%25==0: print(f'Time: {t}, Val Loss: {val_loss:.2f}, Theta RMSE: {np.sqrt(val_loss0[i]):.2f}, Velo RMSE: {np.sqrt(val_loss1[i]):.2f}, Acc RMSE: {np.sqrt(val_loss2[i]):.2f}')
    
        # Model weight saving
        os.makedirs(args.model_path, exist_ok=True)
        torch.save(model.state_dict(), args.model_path + f'model_all_last_{args.exp}.pth')
        if val_loss.sum() < best_val_loss:
            best_val_loss = val_loss.sum()
            torch.save(model.state_dict(), args.model_path + f'model_all_best_{args.exp}.pth')
        
        if val_loss0.sum() < best_theta_loss: best_theta_loss = val_loss0.sum()
        
        writer.add_scalar('Loss/train', train_loss, epoch)
        writer.add_scalar(f'Loss/validation', val_loss, epoch)
        writer.add_scalar(f'RMSE/best_theta', np.sqrt(best_theta_loss), epoch)
        for i,t in enumerate(times):
            writer.add_scalar(f'RMSE_{t}/theta', np.sqrt(val_loss0[i]), epoch)
            writer.add_scalar(f'RMSE_{t}/velocity', np.sqrt(val_loss1[i]), epoch)
            writer.add_scalar(f'RMSE_{t}/acceleration', np.sqrt(val_loss2[i]), epoch)
        writer.add_scalar('LearningRate', scheduler.get_last_lr()[-1], epoch)

        if not((epoch+1)%args.scheduler_step): scheduler.step()
    
    end_time = time.time()
    writer.close()
    print(f"Total time taken {(end_time-start_time)/3600:.2f} hours. Took {(end_time-start_time)/args.epochs:.2f}s per epoch.")

def eval_time_independent(model, test_loader, args, times):
    model.eval()
    loss_fn = nn.L1Loss()
    loss_fn1 = nn.MSELoss()
    test_loss0 = 0
    test_loss1 = 0

    len_t = len(times)
    test_loss0, test_loss1 = np.zeros(len_t), np.zeros(len_t)
    start_time = time.time()
    outputs = []
    for i,t in enumerate(times):
        inputs, outputs_t = [], []
        for data in test_loader:
        
            inp = data[:,:,:11]         # theta_0, v_(-4)-v_(0), a_(-4)-a_(0)
            target = data[:,:,11:]      # theta_target, gaussian_velocity_target, gaussian_acceleration_target

            output = model(inp, t)
            loss0 = loss_fn(output[0][:,:].flatten(), target[:,:,i].flatten()) # MAE of theta
            loss1 = loss_fn1(output[0][:,:].flatten(), target[:,:,i].flatten())

            inputs.append(data.cpu().numpy())
            output_np = np.array([output[0].cpu().detach().numpy()]) #, output[1].cpu().detach().numpy(), output[2].cpu().detach().numpy()])
            outputs_t.append(output_np)

            test_loss0[i] += loss0.item()*data.shape[0]
            test_loss1[i] += loss1.item()*data.shape[0]

        test_loss0[i] /= len(test_loader.dataset)
        test_loss1[i] /= len(test_loader.dataset)
        outputs.append(np.concatenate(outputs_t, axis=1))

        print(f'Time: {t}, Theta MAE: {test_loss0[i]:.2f}, Theta MSE: {test_loss1[i]:.2f}')
    end_time = time.time()
    print(f'Total time: {end_time-start_time}s, Average time: {(end_time-start_time)/len(test_loader)/len(times):.2f}s')

    inputs = np.concatenate(inputs, axis=0)
    outputs = np.concatenate(outputs, axis=-1)

    os.makedirs('Results', exist_ok=True)
    np.save('Results/inputs.npy', inputs)
    np.save(f'Results/outputs_{args.exp}.npy', outputs)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='TA-GNN')
    parser.add_argument('--is_eval', action='store_true', default=False, help='Run evaluation mode')
    parser.add_argument('--resume', action='store_true', default=False, help='Start from last saved checkpoint')
    parser.add_argument('--exp', type=str, default='Baseline', help='Experiment name')
    parser.add_argument('--data_path', type=str, default='Theta', help='Data directory')
    parser.add_argument('--model_path', type=str, default='Checkpoints/', help='Model save directory')

    parser.add_argument('--epochs', type=int, default=50, help='Number of epochs')
    parser.add_argument('--batch_size', type=int, default=2048, help='Batch size')

    parser.add_argument('--lr', type=float, default=0.001, help='Learning rate')
    parser.add_argument('--gamma', type=float, default=0.95, help='Gamma for scheduler')
    parser.add_argument('--scheduler_step', type=int, default=20, help='Number of epochs between scheduler steps')
    parser.add_argument('--weight_decay', type=float, default=0.0, help='Weight decay')
    
    parser.add_argument('--filter_hidden_size', type=int, default=32, help='Filter LSTMs hidden size')
    parser.add_argument('--filter_num_layers', type=int, default=1, help='Filter LSTMs num layers')
    parser.add_argument('--lstm_hidden_size', type=int, default=32, help='Model LSTMs hidden size')
    parser.add_argument('--lstm_num_layers', type=int, default=1, help='Model LSTMs num layers')
    parser.add_argument('--dropout_rate', type=float, default=0.3, help='Model dropout rate')
    parser.add_argument('--gnn_num_layers', type=int, default=7, help='GNN GCNConv num layers')
    parser.add_argument('--gnn_hidden_dim', type=int, default=32, help='GNN GCNConv hidden dimension')

    args = parser.parse_args()

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    model = Model(args, device=device).to(device)
    print(f"Model params: {sum(p.numel() for p in model.parameters())}")

    if args.is_eval:
        times = list(range(20, 401, 20))
        model.load_state_dict(torch.load(args.model_path + f'model_all_best_{args.exp}.pth'))
        test_dataset = Dataset(args, split='test', device=device, times=times)
        test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=args.batch_size, shuffle=False)
        eval_time_independent(model, test_loader, args, torch.Tensor(times).to(device))
        
    else:
        times = list(range(40, 401, 40))
        loss_weights = torch.tensor([2.0, 3.5, 3.5, 4.5, 4.5, 4.5, 2.5, 2.0, 1.0, 1.0]).to(device).reshape((1,1,-1))
        if args.resume: model.load_state_dict(torch.load(args.model_path + f'model_all_last_{args.exp}.pth'))
        train_dataset = Dataset(args, split='train', device=device, times=times)
        val_dataset = Dataset(args, split='valid', device=device, times=times)
        train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True)
        val_loader = torch.utils.data.DataLoader(val_dataset, batch_size=args.batch_size, shuffle=True)
        train_time_independent(model, train_loader, val_loader, args, torch.Tensor(times).to(device), loss_weights)
        test_dataset = Dataset(args, split='test', device=device, times=times)
        test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=args.batch_size, shuffle=False)
        eval_time_independent(model, test_loader, args, torch.Tensor(times).to(device))
