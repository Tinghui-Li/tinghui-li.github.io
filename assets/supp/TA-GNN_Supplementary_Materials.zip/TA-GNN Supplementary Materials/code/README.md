## TA-GNN: Physics Inspired Time-Agnostic Graph Neural Network for Finger Motion Prediction

We include training and testing code along with the model checkpoint for verification. Unfortunately, the training is not possible due to file size limitations. Use the following terminal commands for testing.

    conda create -n tagnn python=3.10
    conda activate tagnn
    pip install torch==2.0.0 torchvision==0.15.1 torchaudio==2.0.1 --index-url https://download.pytorch.org/whl/cu118
    pip install torch_geometric torch_scatter torch_sparse torch_cluster torch_spline_conv -f https://data.pyg.org/whl/torch-2.0.0+cu118.html
    pip install pandas scipy tensorboard
    python TA-GNN.py --is_eval