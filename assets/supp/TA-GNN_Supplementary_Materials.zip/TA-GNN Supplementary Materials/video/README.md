## TA-GNN: Physics Inspired Time-Agnostic Graph Neural Network for Finger Motion Prediction

The videos in this folder contain the predictions from the current time to the future 400 ms. 

Left: Ground-Truth
Middle: TA-GNN
Right: Comparison between Ground-Truth and TA-GNN

We randomly pick several motions and show the corresponding videos in the finger motion capture dataset. 
